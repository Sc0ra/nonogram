"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require('source-map-support').install();
const aws_serverless_express_1 = require("aws-serverless-express");
const app_1 = require("./app");
// NOTE: If you get ERR_CONTENT_DECODING_FAILED in your browser, this is likely
// due to a compressed response (e.g. gzip) which has not been handled correctly
// by aws-serverless-express and/or API Gateway. Add the necessary MIME types to
// binaryMimeTypes below, then redeploy (`npm run package-deploy`)
const binaryMimeTypes = [];
const app = app_1.configureApp();
const server = aws_serverless_express_1.createServer(app, undefined, binaryMimeTypes);
exports.http = (event, context) => aws_serverless_express_1.proxy(server, event, context);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGFtYmRhLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDeEMsbUVBQTZEO0FBRTdELCtCQUFxQztBQUVyQywrRUFBK0U7QUFDL0UsZ0ZBQWdGO0FBQ2hGLGdGQUFnRjtBQUNoRixrRUFBa0U7QUFDbEUsTUFBTSxlQUFlLEdBQWEsRUFrQmpDLENBQUM7QUFDRixNQUFNLEdBQUcsR0FBRyxrQkFBWSxFQUFFLENBQUM7QUFDM0IsTUFBTSxNQUFNLEdBQUcscUNBQVksQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0FBRWhELFFBQUEsSUFBSSxHQUFHLENBQUMsS0FBVSxFQUFFLE9BQWdCLEVBQUUsRUFBRSxDQUNuRCw4QkFBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMifQ==